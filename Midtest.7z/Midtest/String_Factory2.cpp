#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N 200

typedef struct chunk
{
    unsigned char* ch;
    struct chunk* next;
}chunk;
typedef struct
{
    chunk* head, * tail;
    int curlen;
}string;
typedef int status;

string* Readstring();
void Insert(string* s1, int pos, char* s2);
void Clear(string* s);
void Print(string* s);

int main()
{
    int T;
    scanf("%d", &T);
    while (T--)
    {
        string* s1 = Readstring();
        int n;
        char temp[81];
        scanf("%d %s", &n, temp);
        Insert(s1, n, temp);
        Print(s1);
        Clear(s1);
    }
    return 0;
}

#define M 100005
string* Readstring(){
    string *str = (string *)malloc(sizeof(string));
    str->curlen = 0;
    char tem;
    int num = 0;
    getchar();
    str->tail = (struct chunk*)malloc(sizeof(struct chunk));
    str->tail->ch = (unsigned char *)malloc(M * sizeof(unsigned char));
    for(int i = 0; i < M; i++) str->tail->ch[i] = '\0';
    str->tail->next = NULL;
    str->head = str->tail;
    while((tem = getchar()) != '\n'){
        str->tail->ch[num % M] = tem;
        num++;
        if(num % M == 0){
            chunk *ne = (struct chunk*)malloc(sizeof(struct chunk));
            ne->ch = (unsigned char *)malloc(M * sizeof(unsigned char));
            for(int i = 0; i < M; i++) ne->ch[i] = '\0';
            ne->next = NULL;
            str->tail->next = ne;
            str->tail = str->tail->next;
        }
    }
    return str;
}

void Insert(string* s1, int pos, char* s2){
    int len = 0;
    if(pos % M == 0){
        int pp = pos / M;
        chunk *tem = s1->head;
        chunk *neww = (struct chunk *)malloc(sizeof(struct chunk));
        neww->ch = (unsigned char *)malloc(M * sizeof(unsigned char));
        for(int i = 0; i < M; i++) 
            neww->ch[i] = '\0';
        for(int i = 0; s2[i] != '\0'; i++) neww->ch[i] = s2[i];
        if(pos == 0){ 
            neww->next = s1->head;
            s1->head = neww;
            return ;
        }
        pp--;
        while(pp--)
            tem = tem->next;
        neww->next = tem->next;
        tem->next = neww;
    }
    else{
        int pp = pos / M + 1;
        chunk *tem = s1->head;
        pp--;
        while(pp--) tem = tem->next;
        pp = pos % M;
        pp--;
        unsigned char *ori = tem->ch;
        chunk *latter = (struct chunk *)malloc(sizeof(struct chunk));
        latter->ch = (unsigned char *)malloc(M * sizeof(unsigned char));
        for(int i = 0; i < M; i++) latter->ch[i] = '\0';
        if(ori[pp + 1] != '\0'){
            int i = 0;
            for(i = 0; ori[pp + i + 1] != '\0'; i++) latter->ch[i] = ori[pp + 1 + i];
            latter->next = tem->next;
            tem->next = latter;
            ori[pp + 1] = '\0';
        }
        chunk *neww = (struct chunk *)malloc(sizeof(struct chunk));
        neww->ch = (unsigned char *)malloc(M * sizeof(unsigned char));
        for(int i = 0; i < M; i++) neww->ch[i] = '\0';
        for(int i = 0; s2[i] != '\0'; i++) 
            neww->ch[i] = s2[i];
        neww->next = tem->next;
        tem->next = neww;
    }
}

void Clear(string* s){
    chunk *q;
    chunk *h = s->head->next;
    q = s->head;
    while(h){
        if(q->ch != NULL)free(q->ch);
        free(q);
        q = h;
        h = h->next;
    }
    free(s);
}

void Print(string* s){
    chunk *pos = s->head;
    while(pos){
        printf("%s", pos->ch);
        pos = pos->next;
    }
    free(pos);
    printf("\n");
}