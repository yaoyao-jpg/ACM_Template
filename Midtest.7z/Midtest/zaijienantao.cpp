#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define N 30

int n;
char maze[N][N];

typedef struct Position
{
    int x;
    int y;
}Pos,QElemType;

typedef int Status;

typedef struct QNode
{
    QElemType data;
    struct QNode *next;
}QNode, *QueuePtr;
typedef struct
{
    QueuePtr front;
    QueuePtr rear;
}LinkQueue;

int EscapePath(Pos source, Pos destination);

int main()
{
    scanf("%d\n", &n);
    for (int i = 0; i < n; i++)
        getline(maze[i]);

    Pos source, destination;
    scanf("%d %d", &source.x, &source.y);
    scanf("%d %d", &destination.x, &destination.y);

    printf("%d\n", EscapePath(source, destination));

    return 0;
}

void push(LinkQueue *Q, Pos x){
    QueuePtr tem = (QueuePtr)malloc(sizeof(struct QNode));
    tem->data = x;
    Q->rear->next = tem;
    Q->rear = tem;
    tem->next = NULL;
} 

Pos pop(LinkQueue *Q){
    // if(Q->front == Q->rear) return ;
    Pos res = Q->front->next->data;
    // if(Q->front->next == Q->rear){
    //     Q->rear = Q->front;
    //     Q->rear->next = NULL;
    //     return 1;
    // }
    if(Q->front->next == Q->rear){ 
        Q->rear = Q->front;
        Q->rear->next = NULL;
    }
    else Q->front->next = Q->front->next->next;

    return res;
}

int go[4][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
int step[1000][1000];

int EscapePath(Pos source, Pos destination){
    LinkQueue *que = (LinkQueue *)malloc(sizeof(LinkQueue));
    que->rear = que->front = (QueuePtr)malloc(sizeof(QNode));
    que->rear->next = NULL;
    Pos at = source;
    push(que, at);
    step[at.x][at.y] = 1;
    maze[at.x][at.y] = '#';
    while(!(at.x == destination.x && at.y == destination.y)){
        if(que->front == que->rear) break;
        at = pop(que);
        for(int i = 0; i < 4; i++){
            int tx = at.x + go[i][0], ty = at.y + go[i][1];
            if(tx < 0 || tx >= n || ty < 0 || ty >= n || maze[tx][ty] == '#') continue;
            maze[tx][ty] = '#';
            step[tx][ty] = step[at.x][at.y] + 1;
            Pos x = {tx, ty};
            push(que, x);
        }
    }
    return step[destination.x][destination.y] - 1;
}