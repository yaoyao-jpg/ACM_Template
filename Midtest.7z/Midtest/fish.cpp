#include <stdlib.h>
#include <stdio.h>

typedef int Status;
typedef int QElemType;
typedef struct QNode
{
    QElemType data;
    struct QNode *next;
}QNode, *QueuePtr;
typedef struct
{
    QueuePtr front;
    QueuePtr rear;
}LinkQueue;

Status InitQueue(LinkQueue *Q);
Status EnQueue(LinkQueue *Q, QElemType e);
Status DeQueue(LinkQueue *Q, QElemType *e);
int Capture (LinkQueue *Q, int Len, int N, int Cnt);

int main()
{
    int n, m, i;
    scanf("%d %d", &n, &m);
    LinkQueue * queue = (LinkQueue *)malloc(sizeof(LinkQueue));
    InitQueue(queue);
    for (i = 1; i <= n; i++)
        EnQueue(queue, i);
    for (i = 0; i < m; i++)
    {
        int len;
        scanf("%d", &len);
        printf("%d\n", Capture(queue, len, n, i));
    }

  return 0;

}

Status InitQueue(LinkQueue *Q){
    Q->front = Q->rear = (QueuePtr)malloc(sizeof(struct QNode));
    Q->front->next = NULL;
    return 1;
}

Status EnQueue(LinkQueue *Q, QElemType e){
    QueuePtr tem = (QueuePtr)malloc(sizeof(struct QNode));
    tem->data = e;
    Q->rear->next = tem;
    Q->rear = tem;
    tem->next = 0;
    return 1;
}

Status DeQueue(LinkQueue *Q, QElemType *e){
    if(Q->front == Q->rear) return 0;
    *e = Q->front->next->data;
    // if(Q->front->next == Q->rear){
    //     Q->rear = Q->front;
    //     Q->rear->next = NULL;
    //     return 1;
    // }
    Q->front->next = Q->front->next->next;
    return 1;
}

int Capture (LinkQueue *Q, int Len, int N, int Cnt){
    int jump = (Len - 1) % (N - Cnt);
    int *e = (int *)malloc(sizeof(int));
    DeQueue(Q, e);
    for(int i = 1; i <= jump; i++){
        EnQueue(Q, *e);
        DeQueue(Q, e);
    }
    return *e;
}