#include <iostream>
using namespace std;
#define STACK_INIT_SIZE 100

typedef int Stack_ElemType;
typedef struct Stack{
    Stack_ElemType *base;
    Stack_ElemType *top;
    int stack_size;
    // stack_size represents the max number of elements that can be stored in the stack, which equals to the STACK_INIT_SIZE
    int stack_length;
    // length represents the number of elements int the stack
} my_stack;

bool InitStack(my_stack &S); // To initialize the stack
bool StackEmpty(my_stack S);  // To test whether the stack is empty, if so return true, else return false
bool GetTop(my_stack S, Stack_ElemType &e); // Get top element of the stack and store it in "e".
bool Push(my_stack &S, Stack_ElemType e); // Push the element "e" into the top of the stack
bool Pop(my_stack &S); // Simply pop out the top element of the stack S.
void Convertion(my_stack &S, long long num); // To convert the decimal number "num" into binary number and store it in the stack
void PrintStack(my_stack S); // Print the whole stack, which ihas the binary number inside
void StackClear(my_stack &S); // To clear the stack and make it empty

int main(){
    my_stack S;
    InitStack(S);
    long long num = 0;
    int que = 0;
    scanf("%d", &que);
    while(que--){
        StackClear(S);
        scanf("%lld", &num);
        Convertion(S, num);
        PrintStack(S);
    }
    return 0;
}

void StackClear(my_stack &S){
    S.top = S.base;
    S.stack_length = 0;
}

void Convertion(my_stack &S, long long num){
    if(num == 0)
        Push(S, 0);
    while(num){
        Push(S, num % 2);
        num /= 2;
    }
}