#include<iostream>
#include<cstring>
using namespace std;
const int N = 1e5 + 10;

int t;
string S, T;
int ne[N];

void get_next(string tt); 

int main(){
//	freopen("1.in", "r", stdin);
//	freopen("2.out", "w", stdout);
	cin >> t;
	while(t--){
		S.clear(), T.clear();
		cin >> S >> T;
		get_next(T);
		int i = 0, j = 0;
		int flag = -1;
		while(i < S.length() && j < T.length()){
			if(j == 0 || S[i] == T[j]){
			 	i++, j++;
				if(j == T.length()){
					flag = i - T.length();
					break;
				}
			}
			else j = ne[j];
		}
		cout << flag << endl;
	}
	return 0;
}

void get_next(string tt){
	memset(ne, 0, sizeof ne);
	int len = tt.length();
	int i = 1, j = 0;
	while(i < len){
		if(j == 0 || tt[i] == tt[j]) {
			i++, j++;
			ne[i] = j;
		}
		else j = ne[j];
	}
}
