#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N 200
#define MAXLEN 2010

typedef struct
{
    char* ch;
    int length;
}string;
typedef int status;

status Assign(string* str, char* chars);
status Clear(string* str);
int Length(string* str);
status Concat(string* res, string* s1, string* s2);
status Substr(string* res, string* str, int pos, int len);
void Write(string * res);

string str[N];

int main()
{
    int n, m;
    scanf("%d %d", &n, &m);
    for (int i = 1; i <= n; i++)
    {
        char temp[MAXLEN];
        scanf("%s", temp);
        Assign(str + i, temp);
    }

    for (int i = 0; i < m; i++)
    {
        int op;
        scanf("%d", &op);
        string* product = NULL;
        switch (op)
        {
        case 1:
        {
            int a, b;
            scanf("%d %d", &a, &b);
            product = (string*)malloc(sizeof(string));
            product->ch = NULL;
            Concat(product, str + a, str + b);
            break;
        }
        case 2:
        {
            int a, b, c;
            scanf("%d %d %d", &a, &b, &c);
            product = (string*)malloc(sizeof(string));
            product->ch = NULL;
            Substr(product, str + a, b, c);
            break;
        }
        }
        if (product)
        {
                        Write(product);
            Clear(product);
        }
    }
    return 0;
}

status Assign(string* str, char* chars){
    if(str->ch) free(str->ch);
    int len = 0;
    for(char *c = chars; *c; ++len, ++c)  ;
    if(!len){
        str->ch = NULL, str->length = len;
    }
    else{
        str->ch = (char *)malloc((len + 1) * sizeof(char));
        if(!str->ch) exit(1);
        for(int i = 0; i <= len; i++) str->ch[i] = chars[i];
        str->length = len;
    }
    return 1;
}

status Clear(string* str){
    if(str->ch) free(str->ch), str->ch = NULL;
    str->length = 0;
    return 1;
}

int Length(string* str){
    return str->length;
}

status Concat(string* res, string* s1, string* s2){
    if(res->ch) free(res->ch);
    int len = s1->length + s2->length;
    res->ch = (char *)malloc((len + 1) * sizeof(char));
    if(!res->ch) exit(1);
    res->length = len;
    for(int i = 0; i < s1->length; i++) res->ch[i] = s1->ch[i];
    for(int i = 0; i <= s2->length; i++) res->ch[i + s1->length] = s2->ch[i];
    // res->ch[len] = '\0';
    return 1;
}

// int min(int a, int b){
//     if(a < b) return a;
//     else return b;
// }

status Substr(string* res, string* str, int pos, int len){
    if(pos < 0 || pos >= str->length || len < 0 || pos + len > str->length + 1) return 0;
    if(res->ch) free(res->ch);
    // int length = min(len, str->length - pos);
    if(len == 0){
        res->length = 0;
        res->ch = NULL;
        return 1;
    }
    res->length = len;
    res->ch = (char *)malloc((len + 1) * sizeof(char));
    for(int i = 0; i < len; i++) res->ch[i] = str->ch[i + pos];
    res->ch[len] = '\0';
    return 1;
}