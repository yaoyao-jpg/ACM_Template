#include <stdio.h>
#include <stdlib.h>

#define ElementType int
#define ERROR 1e5
typedef enum { push, pop, inject, eject, end } Operation;

typedef struct Node *PtrToNode;
struct Node {
    ElementType Element;
    PtrToNode Next, Last;
};
typedef struct DequeRecord *Deque;
struct DequeRecord {
    PtrToNode Front, Rear;
};
Deque CreateDeque();
int Push( ElementType X, Deque D );
ElementType Pop( Deque D );
int Inject( ElementType X, Deque D );
ElementType Eject( Deque D );

Operation GetOp();          /* details omitted */
void PrintDeque( Deque D ); /* details omitted */

int main()
{
    ElementType X;
    Deque D;
    int done = 0;

    D = CreateDeque();
    while (!done) {
        switch(GetOp()) {
        case push: 
            scanf("%d", &X);
            if (!Push(X, D)) printf("Memory is Full!\n");
            break;
        case pop:
            X = Pop(D);
            if ( X==ERROR ) printf("Deque is Empty!\n");
            break;
        case inject: 
            scanf("%d", &X);
            if (!Inject(X, D)) printf("Memory is Full!\n");
            break;
        case eject:
            X = Eject(D);
            if ( X==ERROR ) printf("Deque is Empty!\n");
            break;
        case end:
            PrintDeque(D);
            done = 1;
            break;
        }
    }
    return 0;
}

Deque CreateDeque(){
    Deque Q = (Deque)malloc(sizeof(struct DequeRecord));
    Q->Front = Q->Rear = (PtrToNode)malloc(sizeof(struct Node));
    Q->Front->Next = NULL;
    Q->Front->Last = NULL;
    return Q;
}

int Push( ElementType X, Deque D ){
    PtrToNode tem = (PtrToNode)malloc(sizeof(struct Node));
    if(!tem) return 0;
    tem->Element = X;
    if(D->Front == D->Rear){
        D->Front->Next = tem;
        tem->Last = D->Front;
        D->Rear = tem;
        tem->Next = NULL;
        return 1;
    }
    tem->Last = D->Front;
    tem->Next = D->Front->Next;
    D->Front->Next->Last = tem;
    D->Front->Next = tem;
    return 1;
}

ElementType Pop( Deque D ){
    if(D->Front == D->Rear) return ERROR;
    int tem = D->Front->Next->Element;
    if(D->Front->Next == D->Rear){
        D->Rear = D->Front;
        D->Front->Next = NULL;
        return tem;
    }
    D->Front->Next->Next->Last = D->Front;
    D->Front->Next = D->Front->Next->Next;
    return tem;
}

int Inject( ElementType X, Deque D ){
    PtrToNode tem = (PtrToNode)malloc(sizeof(struct Node));
    if(!tem) return 0;
    tem->Element = X;
    if(D->Front == D->Rear){
        D->Rear = tem;
        tem->Next = NULL;
        D->Front->Next = tem;
        tem->Last = D->Front;
        return 1;
    }
    tem->Last = D->Rear;
    D->Rear->Next = tem;
    D->Rear = tem;
    tem->Next = NULL;
    return 1;
}

ElementType Eject( Deque D ){
    if(D->Front == D->Rear) return ERROR;
    int tem = D->Rear->Element;
    D->Rear->Last->Next = NULL;
    D->Rear = D->Rear->Last;
    return tem;
}