#include <stdio.h>
#include <stdlib.h>

const int N = 100;

int check(int Jie[],int n);
int main()
{
    int n;  int Jie[N];
    scanf("%d",&n);
    for(int i=1;i<=n;++i)//注意，数组从1开始读入！
        scanf("%d",&Jie[i]);
    if(check(Jie,n))
        printf("Yes");
    else
        printf("No");
}

int check(int Jie[],int n){
    int pos = 1;
    int end = 1;
    int tem[1000];
    for(int i = 1; i <= n; i++){
        tem[end++] = i;
        while(tem[end - 1] == Jie[pos]) pos++, end--;
    }
    for(pos; pos <= n; ){
        if(tem[end - 1] == Jie[pos]) pos++, end--;
        else return 0;
    }
    return 1;
}