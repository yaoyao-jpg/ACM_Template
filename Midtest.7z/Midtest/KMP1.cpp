#include<iostream>
#include<cstring>
using namespace std;
 
const int N = 1e6 + 10;

int t;
string str;
int ne[N];
 
void solve();
void get_ne();
 
int main(){
	// freopen("KMP3.txt", "r", stdin);
	// freopen("out3.out", "w", stdout); 
	cin >> t;
	while(t--){
		solve();
	}
	return 0;
}

void solve(){
 	str.clear();
 	cin >> str;
 	get_ne();
	int len = str.length();
	if(len % (len - ne[len]) == 0) cout << len / (len - ne[len]) << endl;
	else cout << 1 << endl;
}

void get_ne(){
	memset(ne, 0, sizeof ne);
	int len = str.length();
	int i = 1, j = 0;
	while(i < len){
		if(j == 0 || str[i] == str[j]) {
			i++, j++;
			ne[i] = j;
		}
		else j = ne[j];
	}
}
