#include <iostream>
using namespace std;
#define STACK_INIT_SIZE 100

typedef int Stack_ElemType;
typedef struct Stack{
        Stack_ElemType *base;
        Stack_ElemType *top;
        int stack_size;
        int stack_length;
} my_stack;

bool InitStack(my_stack &S);
bool DestroyStack(my_stack &S);
bool StackEmpty(my_stack S);
int StackLength(my_stack S);
bool GetTop(my_stack S, Stack_ElemType &e);
bool Push(my_stack &S, Stack_ElemType e);
bool Pop(my_stack &S);

int main(){
        my_stack S;

        if(!InitStack(S)){ 
                printf("Failed to initialize, program exit\n");
                return 0;
        }

        int data_size = 0;
        scanf("%d", &data_size);

        while(data_size--){
                int data = 0;
                scanf("%d", &data);
                if(!Push(S, data)) printf("Stack Overflow\n");
                else printf("%d is pushed into the stack\n", data);
        }

        while(!StackEmpty(S)){
                int tem = 0;
                if(!(GetTop(S, tem))) printf("Illegal operation: get top from an empty stack\n");
                else {
                        printf("The top element of the stack is %d\n", tem);
                        Pop(S);
                }
        }

        DestroyStack(S);

        return 0;
}

bool GetTop(my_stack S, Stack_ElemType &e){
    if(S.stack_length == 0) return false;
    e = *(S.top - 1);
    return true;
}

bool Push(my_stack &S, Stack_ElemType e){
    if(S.stack_length >= S.stack_size) return false;
    S.stack_length++;
    *S.top++ = e;
    return true;
}

bool Pop(my_stack &S){
    if(S.stack_length == 0) return false;
    S.stack_length--;
    S.top--;
    return true;
}

bool InitStack(my_stack &S){
    S.base = (Stack_ElemType *)malloc(STACK_INIT_SIZE * sizeof(Stack_ElemType));
    if(!S.base) return NULL;
    S.top = S.base;
    S.stack_size = STACK_INIT_SIZE;
    S.stack_length = 0;
    return true;
}